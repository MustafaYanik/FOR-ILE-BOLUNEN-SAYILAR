﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnaktar = new System.Windows.Forms.Button();
            this.lstsayı = new System.Windows.Forms.ListBox();
            this.btnolustur = new System.Windows.Forms.Button();
            this.lst3 = new System.Windows.Forms.ListBox();
            this.lst3ve5 = new System.Windows.Forms.ListBox();
            this.lst5 = new System.Windows.Forms.ListBox();
            this.lst3ve7 = new System.Windows.Forms.ListBox();
            this.lst7 = new System.Windows.Forms.ListBox();
            this.lst5ve7 = new System.Windows.Forms.ListBox();
            this.lstdiger = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnaktar
            // 
            this.btnaktar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnaktar.Location = new System.Drawing.Point(182, 229);
            this.btnaktar.Name = "btnaktar";
            this.btnaktar.Size = new System.Drawing.Size(129, 42);
            this.btnaktar.TabIndex = 0;
            this.btnaktar.Text = ">>AKTAR>>";
            this.btnaktar.UseVisualStyleBackColor = true;
            this.btnaktar.Click += new System.EventHandler(this.button1_Click);
            // 
            // lstsayı
            // 
            this.lstsayı.FormattingEnabled = true;
            this.lstsayı.Location = new System.Drawing.Point(25, 12);
            this.lstsayı.Name = "lstsayı";
            this.lstsayı.Size = new System.Drawing.Size(141, 433);
            this.lstsayı.TabIndex = 1;
            // 
            // btnolustur
            // 
            this.btnolustur.Location = new System.Drawing.Point(25, 451);
            this.btnolustur.Name = "btnolustur";
            this.btnolustur.Size = new System.Drawing.Size(141, 49);
            this.btnolustur.TabIndex = 2;
            this.btnolustur.Text = "OLUŞTUR";
            this.btnolustur.UseVisualStyleBackColor = true;
            this.btnolustur.Click += new System.EventHandler(this.btnolustur_Click_1);
            // 
            // lst3
            // 
            this.lst3.FormattingEnabled = true;
            this.lst3.Location = new System.Drawing.Point(317, 26);
            this.lst3.Name = "lst3";
            this.lst3.Size = new System.Drawing.Size(120, 212);
            this.lst3.TabIndex = 3;
            // 
            // lst3ve5
            // 
            this.lst3ve5.FormattingEnabled = true;
            this.lst3ve5.Location = new System.Drawing.Point(317, 260);
            this.lst3ve5.Name = "lst3ve5";
            this.lst3ve5.Size = new System.Drawing.Size(120, 212);
            this.lst3ve5.TabIndex = 4;
            // 
            // lst5
            // 
            this.lst5.FormattingEnabled = true;
            this.lst5.Location = new System.Drawing.Point(463, 26);
            this.lst5.Name = "lst5";
            this.lst5.Size = new System.Drawing.Size(120, 212);
            this.lst5.TabIndex = 5;
            // 
            // lst3ve7
            // 
            this.lst3ve7.FormattingEnabled = true;
            this.lst3ve7.Location = new System.Drawing.Point(463, 260);
            this.lst3ve7.Name = "lst3ve7";
            this.lst3ve7.Size = new System.Drawing.Size(120, 212);
            this.lst3ve7.TabIndex = 6;
            // 
            // lst7
            // 
            this.lst7.FormattingEnabled = true;
            this.lst7.Location = new System.Drawing.Point(608, 26);
            this.lst7.Name = "lst7";
            this.lst7.Size = new System.Drawing.Size(120, 212);
            this.lst7.TabIndex = 7;
            // 
            // lst5ve7
            // 
            this.lst5ve7.FormattingEnabled = true;
            this.lst5ve7.Location = new System.Drawing.Point(608, 260);
            this.lst5ve7.Name = "lst5ve7";
            this.lst5ve7.Size = new System.Drawing.Size(120, 212);
            this.lst5ve7.TabIndex = 8;
            // 
            // lstdiger
            // 
            this.lstdiger.FormattingEnabled = true;
            this.lstdiger.Location = new System.Drawing.Point(815, 26);
            this.lstdiger.Name = "lstdiger";
            this.lstdiger.Size = new System.Drawing.Size(120, 446);
            this.lstdiger.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(314, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "3 \' BÖLÜNENLER";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(460, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "5 \' BÖLÜNENLER";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(605, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "7 \' BÖLÜNENLER";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(317, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "3 VE 5 BÖLÜNENLER";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(460, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "3 VE 7 BÖLÜNENLER";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(605, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "5 VE 7 BÖLÜNENLER";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(812, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "BÖLÜNMEYENLER";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 512);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstdiger);
            this.Controls.Add(this.lst5ve7);
            this.Controls.Add(this.lst7);
            this.Controls.Add(this.lst3ve7);
            this.Controls.Add(this.lst5);
            this.Controls.Add(this.lst3ve5);
            this.Controls.Add(this.lst3);
            this.Controls.Add(this.btnolustur);
            this.Controls.Add(this.lstsayı);
            this.Controls.Add(this.btnaktar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnaktar;
        private System.Windows.Forms.ListBox lstsayı;
        private System.Windows.Forms.Button btnolustur;
        private System.Windows.Forms.ListBox lst3;
        private System.Windows.Forms.ListBox lst3ve5;
        private System.Windows.Forms.ListBox lst5;
        private System.Windows.Forms.ListBox lst3ve7;
        private System.Windows.Forms.ListBox lst7;
        private System.Windows.Forms.ListBox lst5ve7;
        private System.Windows.Forms.ListBox lstdiger;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

